from django.urls import path
from management import views
  

urlpatterns=[
    path('',views.homepage,name='home'),
    path('login/',views.loginview,name='login'),
    path('register/',views.registerview,name='register'),
    path('logout/',views.logout_view,name='logout'),
    path('stocks/',views.stock_levels,name='stocks'),
    path('supplier/',views.supplier_list,name='supplier'),
    path('trancation/',views.trancations,name='trancations'),
    path('delete/<int:rid>/', views.deleteView, name='delete'),
]