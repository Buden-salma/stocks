from django.db import models
from django.contrib.auth.models import User


# Create your models here.

class Supplier(models.Model):
    name = models.CharField(max_length=25)
    contact_info = models.IntegerField()
    address = models.TextField(max_length=50)

    def __init__ (self):
        return self.name
    
class Product(models.Model):
    name = models.CharField(max_length=255)
    category = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)
    price = models.IntegerField()
    supplier=models.ForeignKey(Supplier,on_delete=models.CASCADE)

    def __init__ (self):
        return self.name

class Inventory(models.Model):
    product = models.OneToOneField(Product, on_delete=models.CASCADE)
    stock_level = models.PositiveIntegerField(default=5)
    reorder_level = models.PositiveIntegerField(default=10)
    last_updated = models.DateTimeField(auto_now=True)


    def __init__ (self):
        return self.product
class Transaction(models.Model):
    TRANSACTION_TYPE_CHOICES = [
        ('IN', 'Stock In'),
        ('OUT', 'Stock Out'),
    ]

    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    quantity = models.PositiveIntegerField()
    transaction_type = models.CharField(max_length=3, choices=TRANSACTION_TYPE_CHOICES)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __inti__ (self):
        return self.transaction_type