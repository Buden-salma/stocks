from django.shortcuts import render,redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout
from management.models import Product
from management.models import Inventory
from management.models import Supplier
from management.models import Transaction
from django.http import HttpResponse

# Create your views here.
def loginview(request):
    if request.user.is_authenticated:  # Fixed typo here
        return redirect('home') 
    if request.method=='POST':
        messages.info(request,'we are going to login you')
        a=request.POST.get('username')
        b=request.POST.get('password')
        obj1=authenticate(request,username=a,password=b)
        if obj1 is not None:
            login(request=request,user=obj1)
            return redirect('home')
        else:
            return redirect('login')
    return render(request,'login.html')
def registerview(request):
    if request.method == 'POST':
        # Get form data
        username = request.POST.get('username')
        first_name = request.POST.get('firstname')
        last_name = request.POST.get('lastname')
        password = request.POST.get('passw')
        confirm_password = request.POST.get('cpass')
        email = request.POST.get('email')

        # Validate inputs
        if not all([username, first_name, last_name, password, confirm_password, email]):
            messages.error(request, "All fields are required.")
            return redirect('register')

        if len(password) < 8:
            messages.error(request, "Password must be at least 8 characters long.")
            return redirect('register')

        if not password[0].isupper():
            messages.error(request, "Password must start with an uppercase letter.")
            return redirect('register')

        if password != confirm_password:
            messages.error(request, "Passwords do not match.")
            return redirect('register')

        # Create the user
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken.")
            return redirect('register')

        user = User.objects.create_user(
            username=username,
            first_name=first_name,
            last_name=last_name,
            email=email,
            password=password
        )
        user.save()
        messages.success(request, "Registration successful. Please log in.")
        return redirect('login')

    return render(request, 'register.html')
def homepage(request):
    product=Product.objects.all()
    return render(request,'home.html',{"all":product})
@login_required(login_url="login")
def stock_levels(request):
    inventory = Inventory.objects.all()
    if request.user.is_superuser:
        if request.method == "POST":
            a=request.POST.get('product')
            b=request.POST.get('stock_level')
            c=request.POST.get('reorder_level')
            d=request.POST.get('last_updated')
            obj1=Inventory(product=a,stock_level=b,reorder_level=c,last_updated=d)
            obj1.save()
            messages.warning(request,"you information is up-to-date")
        return render(request,'stocks.html',{"all":inventory})
    return render(request,'stocks.html',{"all":inventory})
def supplier_list(request):
    obj2=Supplier.objects.all()
    if request.user.is_staff:
        if request.method == "POST":
            a=request.POST.get('name')
            b=request.POST.get('contact_info')
            c=request.POST.get('address')
            obj3=Supplier(name=a,contact_info=b,address=c)
            obj3.save()
        return render(request,'supplier.html',{"all":obj2})
    return render(request,'supplier.html',{"all":obj2})
@login_required(login_url="login")
def trancations(request):
    obj4=Transaction.objects.filter(user=request.user)
    return render(request,'trancation.html',{"all":obj4})

def logout_view(request):
    logout(request)
    return redirect('login')


def deleteView(request, rid):
    if request.user.is_superuser:
        try:
            obj = Supplier.objects.get(id=rid)
            obj.delete()
        except Supplier.DoesNotExist:
            messages.error(request, "The record you are trying to delete does not exist.")
    else:
        messages.error(request, "you are not admin")
    
    return redirect('home')





